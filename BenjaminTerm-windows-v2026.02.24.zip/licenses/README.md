WezTerm bundles some components provided by third parties.
Their respective licenses are included in this directory.
